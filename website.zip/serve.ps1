# Sementis - Local Wi-Fi Web Server
# Serves the portal directory over HTTP on port 8080 using native .NET HttpListener.

$port = 8080
$listener = New-Object System.Net.HttpListener

# Find the computer's local IP address (non-loopback IPv4)
$localIps = Get-NetIPAddress -AddressFamily IPv4 | Where-Object { 
    $_.IPAddress -ne "127.0.0.1" -and 
    $_.InterfaceAlias -notlike "*Loopback*" -and
    $_.IPAddress -notlike "169.254.*"
}

if ($localIps.Count -eq 0) {
    Write-Host "No active network adapters found. Server will run on localhost." -ForegroundColor Yellow
    $listener.Prefixes.Add("http://localhost:$port/")
} else {
    # Listen on all local IP endpoints
    # NOTE: Run PowerShell as Administrator if Windows throws an Access Denied error.
    $listener.Prefixes.Add("http://localhost:$port/")
    foreach ($ip in $localIps) {
        $listener.Prefixes.Add("http://$($ip.IPAddress):$port/")
    }
}

try {
    $listener.Start()
    Write-Host "`n========================================================" -ForegroundColor Green
    Write-Host "🌱 Sementis Portal Web Server Running Successfully!" -ForegroundColor Green
    Write-Host "========================================================" -ForegroundColor Green
    Write-Host "`nTo open the site on your computer, visit:"
    Write-Host "  👉 http://localhost:$port/index.html" -ForegroundColor Cyan
    
    if ($localIps.Count -gt 0) {
        Write-Host "`nTo open the site on ANY PHONE (connected to the same Wi-Fi):"
        foreach ($ip in $localIps) {
            Write-Host "  👉 http://$($ip.IPAddress):$port/index.html" -ForegroundColor Green
        }
    }
    Write-Host "`n--------------------------------------------------------"
    Write-Host "Press Ctrl+C inside this window to STOP the server."
    Write-Host "--------------------------------------------------------`n"

    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response
        
        $url = $request.Url.LocalPath
        if ($url -eq "/") { $url = "/index.html" }
        
        # Build physical path
        $filePath = Join-Path (Get-Location) $url.TrimStart('/')
        
        if (Test-Path $filePath -PathType Leaf) {
            $bytes = [System.IO.File]::ReadAllBytes($filePath)
            
            # Resolve Content-Type
            $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
            $contentType = switch ($ext) {
                ".html" { "text/html; charset=utf-8" }
                ".css"  { "text/css; charset=utf-8" }
                ".js"   { "application/javascript; charset=utf-8" }
                ".png"  { "image/png" }
                ".jpg"  { "image/jpeg" }
                ".jpeg" { "image/jpeg" }
                ".svg"  { "image/svg+xml" }
                default { "application/octet-stream" }
            }
            
            $response.ContentType = $contentType
            $response.ContentLength64 = $bytes.Length
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
        } else {
            $response.StatusCode = 404
            $errBytes = [System.Text.Encoding]::UTF8.GetBytes("404 File Not Found - Sementis Portal")
            $response.ContentType = "text/plain"
            $response.OutputStream.Write($errBytes, 0, $errBytes.Length)
        }
        $response.Close()
    }
} catch {
    Write-Host "Error starting web server: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "TIP: If you get Access Denied, please run PowerShell as Administrator." -ForegroundColor Yellow
} finally {
    if ($listener.IsListening) {
        $listener.Stop()
    }
}
